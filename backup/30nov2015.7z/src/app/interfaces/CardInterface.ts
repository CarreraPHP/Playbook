export interface CardInterface {
	name: string;
	description: string;
	type: string;
	internal: any;
	options: any[];
	actors: any[];
}